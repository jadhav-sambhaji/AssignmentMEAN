import { Component } from '@angular/core';
import{ freeApiService} from './services/freeapi.service';
import {Comments} from './classes/comments';
import { Posts} from './classes/posts';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private _freeApiService:freeApiService) {
    
    
 }

   
 lstcomments:Comments[];
 lstPosts:Posts[];
 objPosts:Posts;

   
  ngOnInit() {
    
       this._freeApiService.getAllStudents()
       .subscribe
       (
         data=>
         {
             this.lstcomments=data;
         }
       );

       this._freeApiService.getStudentDetails()
       .subscribe(

        data=>
        {
            this.lstPosts=data;
        }

       );

       var opost=new Posts();
       opost.body='NEW STUDENT IS ADDED ';
       opost.title='SAMBHAJI JADHAV';
       opost.userId=5;

       this._freeApiService.addStudent(opost)
       .subscribe(
         data=>{
           this.objPosts=data;
           
         }
       )

  }
}
