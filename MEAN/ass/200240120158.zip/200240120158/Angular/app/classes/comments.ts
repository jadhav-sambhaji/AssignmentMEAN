export class Comments
{
    userId='';
    id = '';
    name = '';
    email = '';
    body='';
    
    
}