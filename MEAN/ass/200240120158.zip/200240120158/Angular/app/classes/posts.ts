export class Posts
{
    userId:number;
    id :number;
    title :string;
    body:string;
}
// {
//          userId:number;
//          id :number;
//          title :string;
//          body:string;

//          constructor()
//          {
//              this.userId=  ;
//              this.id=;
//              this.title='';
//              this.body='';

//          }
     
